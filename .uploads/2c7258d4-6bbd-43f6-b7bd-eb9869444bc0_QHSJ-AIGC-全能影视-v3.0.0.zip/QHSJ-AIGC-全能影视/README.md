<div align="center">
  <img src="assets/logo.png" alt="QHSJ AIGC 全能影视" width="180" />
  <h1>QHSJ AIGC 全能影视</h1>
  <p><strong>面向影视与视觉创作的全路由 Agent Skill · QHSJ Film & Visual Production Skill</strong></p>
  <p>
    <img alt="Version" src="https://img.shields.io/badge/version-3.0.0-5B5BD6.svg" />
    <img alt="Language" src="https://img.shields.io/badge/language-中文优先-0E8A16.svg" />
    <img alt="License" src="https://img.shields.io/badge/license-MIT-blue.svg" />
    <img alt="Routing" src="https://img.shields.io/badge/routing-multi--label%20%7C%20auditable-8A2BE2.svg" />
    <img alt="Assets" src="https://img.shields.io/badge/pipeline-asset--lock%20first-orange.svg" />
  </p>
</div>

QHSJ AIGC 全能影视是一套以 `SKILL.md` 为总控入口的影视创作技能包。用户可以用自然中文描述目标，系统按交付物、语义意图、硬约束和隐含依赖选择能力、工作流、知识文件与章节，再执行对应检查。它覆盖从创意、小说/剧本、角色和场景资产，到空间连续性、分镜、图片/视频提示词、模型适配、声音/VFX、工程集成与质量回归的完整工作链。

> **版本边界：** 路由可达、注册清单完整和自动化测试通过，不等于任意自然语言都能被固定规则百分之百正确理解，也不代表外部图像/视频模型已被实际调用。宿主 Agent 必须继续进行语义复核；外部工具调用、生成结果和跨会话持久化均以真实执行结果为准。

## 核心能力

- **中文白话入口，多标签路由：** 同时识别复合目标；把直接命中的能力与必需依赖分开，不把全部依赖误当成要执行的独立创作流程。
- **全资源可审计：** 所有资源、能力、工作流、参考文档章节均有注册数据或图关系；普通任务按需加载，工程审计可保留全量资源候选。
- **资产先行与版本锁定：** 先建立并核验人物、场景、道具资产，再锁定版本和依赖；生成分镜图时必须引用锁定的资产 ID 与版本。
- **空间与物理连续性：** 追踪坐标系、空间锚点、人物位置、人与人距离、身体/头部/眼睛朝向、明确的注视目标、动作起止状态和摄影机路径。
- **质量门禁与回归：** 提供路由脚本、包审计、提示词静态检查、自然语言评估集和单元测试；检查失败应先修复再发布。
- **无损正文去重：** 先按 SHA-256 核实，仅将字节级完全相同的 Markdown 正文合并为一个规范正文；87 个历史路径保留为轻量兼容别名，并在注册表和路由图中继承规范正文的全部章节路由。无任何独有正文被删减。

## 生产链路

```mermaid
flowchart TD
    A[用户白话与原始素材] --> B[意图解析与硬约束仲裁]
    B --> C[多标签能力路由与依赖闭包]
    C --> D[工作流和参考章节选择]
    D --> E[Canon / 资产规格 / 稳定 ID]
    E --> F[生成或接收人物、场景、道具资产]
    F --> G[资产核验与版本锁定]
    G --> H[空间、距离、朝向、视线台账]
    H --> I[分镜与动作/摄影/表演设计]
    I --> J[可选分镜资产：引用已锁定资产]
    J --> K[提示词编译与平台适配]
    K --> L[QA、红队审查、修复与回归]
    L --> M[交付、清单与项目状态更新]
```

资产锁定是分镜资产生成的硬门禁，而不是建议步骤。若角色图、场景图或需要的道具图尚未生成/核验/锁定，工作流必须先停在资产阶段，不能为追求流程完成而伪造锁定状态。

## 目录结构

```text
QHSJ-AIGC-全能影视/
├── SKILL.md                       # 主入口：执行契约、能力介绍、路由规则与使用说明
├── README.md                      # 项目说明与快速开始
├── CHANGELOG.md                   # 版本历史
├── AUDIT_REPORT.md                # 最近一次离线审计与回归结果
├── MANIFEST.json                  # 文件清单、大小和 SHA-256
├── routing/
│   ├── route-registry.json        # 能力/工作流/资源/章节/触发词完整注册表
│   └── route-graph.json           # 能力、依赖、工作流、阶段、资源与章节关系图
├── workflows/                     # 16 条宏观工作流及统一索引
├── references/                    # 规范知识正文、兼容别名与逐文件索引
├── schemas/                       # 项目状态与分镜数据契约
├── templates/                     # 资产锁定台账、空间连续性台账及原有模板
├── scripts/
│   ├── route_request.py           # 中文自然语言路由预览
│   ├── rebuild_routing_assets.py  # 重建注册表、路由图与 Manifest
│   ├── audit_package.py           # 包结构/哈希/引用/Schema/路由图审计
│   ├── run_evals.py               # 路由评估集回归
│   └── validate_prompt.py         # 提示词静态检查
├── tests/                         # 确定性单元测试
├── evals/                         # 中文路由与否定约束用例
└── assets/                        # QHSJ 图标与标识
```

## 快速开始

建议使用 Python 3.10+。运行包审计和单元测试需要 PyYAML；Schema 元验证需要 `jsonschema`。若缺少可选依赖，审计脚本会给出警告，不应把跳过检查误认为通过检查。

```bash
# 1. 查看一次路由计划；这一步不会调用外部图像/视频模型
python scripts/route_request.py "帮我设计角色四视图和场景资产，锁定后引用它们制作分镜图" --json

# 2. 读取路由选择、能力证据与资源候选
python scripts/route_request.py "只要分镜，不要提示词" --json

# 3. 检查提示词文件
python scripts/validate_prompt.py prompt.txt --type video

# 4. 运行全包结构、引用、哈希、Schema、路由图审计
python scripts/audit_package.py

# 5. 运行自然语言路由评估集
python scripts/run_evals.py

# 6. 运行单元回归测试
python -B -m unittest discover -s tests -v

# 7. 当工作流、资源或文档发生变更时，重建路由注册、图与清单
python scripts/rebuild_routing_assets.py
python scripts/audit_package.py
```

**变更规则：** 修改知识文档、工作流、Schema、模板或脚本后，应先运行重建脚本同步章节锚点、资源哈希、图关系和文件 Manifest，再运行审计、评估和单元测试。不要手工编辑生成文件后跳过重建。`MANIFEST.json` 会列出其自身以外的包文件，并保存 SHA-256；路由注册表会为内容资源登记标签和触发入口。

## 使用原则

1. `SKILL.md` 是人类与宿主 Agent 的主使用说明；执行时应继续读取 `routing/route-registry.json`、`workflows/index.yaml` 和对应的工作流 YAML，不能仅靠 README 或固定能力表推断所有模块。
2. `references/index.md` 是 303 个参考 Markdown 路径的可读目录，其中包括指向规范正文的兼容别名。`SKILL.md` 的逐文件路由目录、注册表章节索引与路由图共同支持从能力定位到具体知识章节。
3. “只要分镜”“只要图片提示词”“只设计音效”等否定限制必须被保留；安全与质量门禁仍可运行，但不得擅自增加被明确排除的交付物。
4. 复杂影视项目应把同一人物和场景的身份、外观和空间锚点保存为稳定 ID。若已锁定资产发生修改，必须创建新版本、扫描依赖并回归受影响分镜，不能悄悄覆盖旧版本。
5. 多智能体协作规则在 `references/qhsj-multiagent-review-protocol.md` 中定义。真实执行取决于宿主是否支持并行 Agent；单一模型/运行环境可以按角色顺序完成独立检查，但不得声称实际启动了不存在的 Agent。

## 路由是如何闭环的

```text
自然语言请求
  → intent-analysis（必经入口）
  → 直接意图能力 + 显式排除项
  → 必需依赖闭包（不自动膨胀成无关宏观流程）
  → 主工作流 / 条件工作流
  → 对应资源与章节
  → 结构化状态与质量门禁
  → 路由图、测试与 Manifest 回归
```

全量审计模式会确保**所有注册资源都保留在审计候选中**，普通创作模式则按任务加载相关内容。这里的“全路由”指包内资源有真实可追踪的路由关系与可验证的入口，不是每次请求都运行所有创作能力。

## 协作与运行边界

- 图像、视频、语音模型，云端 API，GitHub 发布，以及外部 Agent 调度均需要宿主工具和相应授权。路由预览脚本只展示计划，不会暗中执行远程请求。
- 项目状态的持久性取决于宿主是否真实写入文件或数据库；仅出现在当前提示上下文中的信息不能被宣称为永久记忆。
- 当前模型和平台能力会变化。涉及实时模型规格、配额、价格、政策或接口字段时，应检索官方或可信来源并记录核验日期；无法核实则标为待验证。
- 自动化验证只能检查其覆盖到的结构、规则和样例，不能数学证明所有未见输入都无错误。发布前应根据实际目标宿主与模型执行端到端试运行。

## 许可证

本项目采用 MIT License，完整条款见 [LICENSE](LICENSE)。
