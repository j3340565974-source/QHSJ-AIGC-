<!-- QHSJ-CONTENT-ALIAS canonical="references/performance-recipes.md" original_sha256="1b916641e7a4119251ff8d826fd245a3bf042ba7b98a44f0d938a9bdc9a66377"-->
# 兼容路由别名：Performance Recipe Library — 240 micro-beat patterns

> 本文件原正文与规范正文完全相同，为避免重复维护，正文只保留一份。

> 规范正文：`references/performance-recipes.md`（[`performance-recipes.md`](performance-recipes.md)）

> 路由、工作流和显式旧路径仍可通过此别名定位规范正文；需要执行任何规则时，必须继续读取上方规范正文，不得把本页当作完整知识正文。
